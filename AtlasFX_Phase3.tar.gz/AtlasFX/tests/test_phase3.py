"""
tests/test_phase3.py
─────────────────────
Tests for Monte Carlo and Walk-Forward validation modules.
Uses synthetic data and known outcomes.
"""

import sys
from datetime import datetime, timedelta
from pathlib import Path
from unittest.mock import patch

import numpy as np
import pandas as pd
import pytest

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from backtesting.engine import BacktestConfig, BacktestEngine, BacktestResults, BacktestTrade
from backtesting.monte_carlo import MonteCarlo, MonteCarloConfig
from backtesting.walk_forward import WalkForwardValidator
from strategies.base import BaseStrategy, StrategyMetadata, TradeSignal


# ── Helpers ───────────────────────────────────────────────────────────────────

def make_synthetic_results(
    n_wins: int,
    n_losses: int,
    win_r: float = 2.0,
    loss_r: float = -1.0,
    initial_balance: float = 10_000.0,
    instrument: str = "EUR_USD",
) -> BacktestResults:
    """Build a BacktestResults with known win/loss sequence."""
    config = BacktestConfig(
        instrument=instrument, timeframe="D",
        start_date="2021-01-01", end_date="2024-01-01",
        initial_balance=initial_balance, risk_per_trade_pct=0.5,
    )
    results = BacktestResults(config=config, strategy_id="TEST_STRATEGY")

    balance = initial_balance
    risk_amt = initial_balance * 0.005

    trades = []
    for i in range(n_wins + n_losses):
        is_win = i < n_wins
        r = win_r if is_win else loss_r
        pnl = risk_amt * abs(r) * (1 if is_win else -1)
        balance_after = balance + pnl

        trades.append(BacktestTrade(
            trade_id=i,
            strategy_id="TEST_STRATEGY",
            instrument=instrument,
            direction="BUY",
            entry_bar=i,
            entry_time=datetime(2021, 1, 1) + timedelta(days=i * 5),
            entry_price=1.1000,
            stop_loss=1.0980,
            take_profit=1.1040,
            exit_bar=i + 1,
            exit_time=datetime(2021, 1, 1) + timedelta(days=i * 5 + 1),
            exit_price=1.1040 if is_win else 1.0980,
            lot_size=1000,
            pnl=round(pnl, 2),
            r_multiple=r,
            close_reason="take_profit" if is_win else "stop_loss",
            spread_cost=0.0,
            commission=0.0,
            balance_before=round(balance, 2),
            balance_after=round(balance_after, 2),
        ))
        balance = balance_after

    results.trades = trades
    results.equity_curve = [initial_balance + i * 10 for i in range(len(trades) + 1)]
    results.equity_dates = [datetime(2021, 1, 1) + timedelta(days=i) for i in range(len(trades) + 1)]
    return results


# ── Monte Carlo Tests ─────────────────────────────────────────────────────────

class TestMonteCarlo:
    def test_requires_minimum_trades(self):
        results = make_synthetic_results(n_wins=3, n_losses=3)
        with pytest.raises(ValueError, match="at least 10 trades"):
            MonteCarlo(results)

    def test_runs_with_sufficient_trades(self):
        results = make_synthetic_results(n_wins=15, n_losses=10)
        mc = MonteCarlo(results, MonteCarloConfig(n_simulations=100, random_seed=42))
        report = mc.run()
        assert report is not None
        assert report.n_simulations == 100

    def test_profitable_strategy_low_ruin(self):
        """A clearly profitable strategy should have low ruin probability."""
        results = make_synthetic_results(n_wins=30, n_losses=10, win_r=2.0)
        mc = MonteCarlo(results, MonteCarloConfig(n_simulations=1000, random_seed=42))
        report = mc.run()
        assert report.probability_of_ruin_pct < 10.0
        assert report.probability_of_profit_pct > 70.0

    def test_losing_strategy_high_ruin(self):
        """A losing strategy should show high ruin probability."""
        results = make_synthetic_results(n_wins=5, n_losses=30, win_r=1.0)
        mc = MonteCarlo(results, MonteCarloConfig(n_simulations=1000, random_seed=42))
        report = mc.run()
        assert report.probability_of_profit_pct < 50.0

    def test_report_has_required_fields(self):
        results = make_synthetic_results(n_wins=20, n_losses=10)
        mc = MonteCarlo(results, MonteCarloConfig(n_simulations=200, random_seed=42))
        report = mc.run()

        assert hasattr(report, "probability_of_ruin_pct")
        assert hasattr(report, "probability_of_profit_pct")
        assert hasattr(report, "median_return_pct")
        assert hasattr(report, "return_percentiles")
        assert hasattr(report, "verdict")
        assert hasattr(report, "verdict_reasons")

    def test_percentiles_are_ordered(self):
        """p5 <= p25 <= p50 <= p75 <= p95"""
        results = make_synthetic_results(n_wins=20, n_losses=15)
        mc = MonteCarlo(results, MonteCarloConfig(n_simulations=500, random_seed=42))
        report = mc.run()
        p = report.return_percentiles
        assert p["p5"] <= p["p25"] <= p["p50"] <= p["p75"] <= p["p95"]

    def test_verdict_fail_for_losing_strategy(self):
        results = make_synthetic_results(n_wins=5, n_losses=40)
        mc = MonteCarlo(results, MonteCarloConfig(n_simulations=500, random_seed=42))
        report = mc.run()
        assert report.verdict == "FAIL"

    def test_deterministic_with_seed(self):
        results = make_synthetic_results(n_wins=20, n_losses=10)
        config = MonteCarloConfig(n_simulations=200, random_seed=99)
        report1 = MonteCarlo(results, config).run()
        report2 = MonteCarlo(results, config).run()
        assert report1.probability_of_ruin_pct == report2.probability_of_ruin_pct
        assert report1.median_return_pct == report2.median_return_pct

    def test_sample_equity_curves_stored(self):
        results = make_synthetic_results(n_wins=20, n_losses=10)
        mc = MonteCarlo(results, MonteCarloConfig(n_simulations=100, random_seed=42))
        report = mc.run()
        assert len(report.sample_equity_curves) > 0
        assert len(report.sample_equity_curves[0]) > 1

    def test_all_final_returns_count(self):
        n_sims = 300
        results = make_synthetic_results(n_wins=15, n_losses=10)
        mc = MonteCarlo(results, MonteCarloConfig(n_simulations=n_sims, random_seed=42))
        report = mc.run()
        assert len(report.all_final_returns) == n_sims

    def test_print_report_runs(self, capsys):
        results = make_synthetic_results(n_wins=20, n_losses=10)
        mc = MonteCarlo(results, MonteCarloConfig(n_simulations=100, random_seed=42))
        report = mc.run()
        MonteCarlo.print_report(report)
        captured = capsys.readouterr()
        assert "MONTE CARLO" in captured.out
        assert "VERDICT" in captured.out


# ── Walk-Forward Tests ────────────────────────────────────────────────────────

def make_ohlcv(n_bars: int = 600, seed: int = 42) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    dates = [datetime(2021, 1, 1) + timedelta(days=i) for i in range(n_bars)]
    closes = [1.1000]
    for _ in range(n_bars - 1):
        closes.append(max(closes[-1] + rng.normal(0, 0.002), 0.5))
    closes = np.array(closes)
    noise = rng.uniform(0.001, 0.003, n_bars)
    return pd.DataFrame({
        "Open": np.roll(closes, 1), "High": closes + noise,
        "Low": closes - noise, "Close": closes,
        "Volume": rng.integers(1000, 5000, n_bars).astype(float),
    }, index=pd.DatetimeIndex(dates))


class NeverTradeStrategy(BaseStrategy):
    METADATA = StrategyMetadata(
        strategy_id="TEST_NEVER", name="Never Trade", version="1.0",
        description="", instruments=["EUR_USD"], timeframes=["D"], min_history_bars=5,
    )
    def generate_signal(self, data, instrument, timeframe, current_bar_index=-1):
        return None


class TestWalkForward:
    def test_builds_correct_number_of_windows(self):
        validator = WalkForwardValidator(
            instrument="EUR_USD", timeframe="D",
            full_start="2021-01-01", full_end="2024-01-01",
            n_windows=4, oos_pct=0.3,
        )
        data = make_ohlcv(1000)
        windows = validator._build_windows(data)
        assert len(windows) == 4

    def test_oos_follows_is_in_time(self):
        validator = WalkForwardValidator(
            instrument="EUR_USD", timeframe="D",
            full_start="2021-01-01", full_end="2024-01-01",
            n_windows=3, oos_pct=0.3,
        )
        data = make_ohlcv(800)
        windows = validator._build_windows(data)
        for is_start, is_end, oos_start, oos_end in windows:
            assert is_end < oos_start
            assert oos_start <= oos_end

    def test_run_with_no_signal_strategy(self):
        data = make_ohlcv(600)
        validator = WalkForwardValidator(
            instrument="EUR_USD", timeframe="D",
            full_start="2021-01-01", full_end="2022-08-01",
            n_windows=3, oos_pct=0.3,
        )
        strategy = NeverTradeStrategy()
        with patch.object(validator._downloader, "load_for_backtest", return_value=data):
            # Also patch each engine's downloader
            with patch("backtesting.engine.HistoricalDownloader") as mock_dl:
                mock_dl.return_value.load_for_backtest.return_value = data
                report = validator.run(strategy)

        assert report is not None
        assert len(report.windows) == 3
        assert report.total_oos_trades == 0

    def test_report_fields_populated(self):
        data = make_ohlcv(600)
        validator = WalkForwardValidator(
            instrument="EUR_USD", timeframe="D",
            full_start="2021-01-01", full_end="2022-08-01",
            n_windows=3, oos_pct=0.3,
        )
        strategy = NeverTradeStrategy()
        with patch.object(validator._downloader, "load_for_backtest", return_value=data):
            with patch("backtesting.engine.HistoricalDownloader") as mock_dl:
                mock_dl.return_value.load_for_backtest.return_value = data
                report = validator.run(strategy)

        assert hasattr(report, "verdict")
        assert hasattr(report, "total_oos_trades")
        assert hasattr(report, "oos_profit_factor")
        assert report.n_windows == 3
