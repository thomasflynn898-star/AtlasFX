"""
backtesting/walk_forward.py
────────────────────────────
Walk-forward validation for AtlasFX strategies.

Walk-forward testing is the closest simulation we can do to live trading.
It works by:
    1. Splitting the full data into sequential windows
    2. Each window has an IN-SAMPLE period (would-be optimisation)
       and an OUT-OF-SAMPLE period (would-be live trading)
    3. The strategy is tested on out-of-sample data only
    4. Results across all out-of-sample windows are combined

This catches overfitting: a strategy that only works on the data it
was developed on will show strong in-sample results but deteriorate
out-of-sample. A robust strategy performs consistently across windows.

The current implementation uses fixed-parameter walk-forward
(no optimisation per window) — it tests whether the strategy
is robust across time periods using its original parameters.

Usage:
    from backtesting.walk_forward import WalkForwardValidator
    from strategies.strategy_macd_ema import MACDEMAStrategy

    validator = WalkForwardValidator(
        instrument="XAU_USD",
        timeframe="D",
        full_start="2021-06-01",
        full_end="2026-06-01",
        n_windows=5,
        oos_pct=0.3,
    )
    report = validator.run(MACDEMAStrategy())
    validator.print_report(report)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta

import pandas as pd

from backtesting.engine import BacktestConfig, BacktestEngine, BacktestResults
from data.downloader import HistoricalDownloader
from logs.logger import get_logger
from strategies.base import BaseStrategy

log = get_logger(__name__)


@dataclass
class WalkForwardWindow:
    """A single walk-forward window."""
    window_number: int
    is_start: str
    is_end: str
    oos_start: str
    oos_end: str
    is_results: BacktestResults    # In-sample
    oos_results: BacktestResults   # Out-of-sample (what counts)


@dataclass
class WalkForwardReport:
    """Full walk-forward validation report."""
    strategy_id: str
    instrument: str
    timeframe: str
    full_period: str
    n_windows: int
    oos_pct: float
    windows: list[WalkForwardWindow] = field(default_factory=list)

    # Aggregated OOS metrics
    total_oos_trades: int = 0
    oos_win_rate_pct: float = 0.0
    oos_profit_factor: float = 0.0
    oos_total_return_pct: float = 0.0
    oos_avg_return_per_window_pct: float = 0.0
    oos_max_drawdown_pct: float = 0.0
    oos_sharpe: float = 0.0
    windows_profitable: int = 0

    # IS vs OOS degradation
    avg_is_return_pct: float = 0.0
    avg_oos_return_pct: float = 0.0
    degradation_pct: float = 0.0   # How much worse OOS vs IS

    verdict: str = "PENDING"
    verdict_reasons: list[str] = field(default_factory=list)


class WalkForwardValidator:
    """
    Fixed-parameter walk-forward validator.

    Tests strategy robustness across sequential time windows.
    Does NOT optimise parameters per window.
    """

    def __init__(
        self,
        instrument: str,
        timeframe: str,
        full_start: str,
        full_end: str,
        n_windows: int = 5,
        oos_pct: float = 0.3,
        initial_balance: float = 10_000.0,
        risk_per_trade_pct: float = 0.5,
        spread_pips: float = 1.2,
        pip_size: float = 0.0001,
    ) -> None:
        self.instrument = instrument
        self.timeframe = timeframe
        self.full_start = full_start
        self.full_end = full_end
        self.n_windows = n_windows
        self.oos_pct = oos_pct
        self.initial_balance = initial_balance
        self.risk_per_trade_pct = risk_per_trade_pct
        self.spread_pips = spread_pips
        self.pip_size = pip_size
        self._downloader = HistoricalDownloader()

    def _build_windows(self, data: pd.DataFrame) -> list[tuple[str, str, str, str]]:
        """
        Build window date ranges.

        Each window covers (full_period / n_windows).
        Within each window: first (1-oos_pct) is IS, last oos_pct is OOS.

        Returns list of (is_start, is_end, oos_start, oos_end) tuples.
        """
        start = pd.Timestamp(self.full_start)
        end = pd.Timestamp(self.full_end)
        total_days = (end - start).days
        window_days = total_days // self.n_windows

        windows = []
        for i in range(self.n_windows):
            w_start = start + timedelta(days=i * window_days)
            w_end = start + timedelta(days=(i + 1) * window_days)
            if i == self.n_windows - 1:
                w_end = end  # Last window gets remainder

            oos_days = int(window_days * self.oos_pct)
            is_end = w_end - timedelta(days=oos_days)
            oos_start = is_end + timedelta(days=1)

            windows.append((
                w_start.strftime("%Y-%m-%d"),
                is_end.strftime("%Y-%m-%d"),
                oos_start.strftime("%Y-%m-%d"),
                w_end.strftime("%Y-%m-%d"),
            ))

        return windows

    def _run_window(
        self,
        strategy: BaseStrategy,
        is_start: str,
        is_end: str,
        oos_start: str,
        oos_end: str,
        window_num: int,
    ) -> WalkForwardWindow:
        """Run a single walk-forward window."""
        log.info(
            "walk_forward_window",
            window=window_num,
            is_period=f"{is_start}→{is_end}",
            oos_period=f"{oos_start}→{oos_end}",
        )

        def make_config(start: str, end: str) -> BacktestConfig:
            return BacktestConfig(
                instrument=self.instrument,
                timeframe=self.timeframe,
                start_date=start,
                end_date=end,
                initial_balance=self.initial_balance,
                risk_per_trade_pct=self.risk_per_trade_pct,
                spread_pips=self.spread_pips,
                pip_size=self.pip_size,
            )

        # In-sample
        is_config = make_config(is_start, is_end)
        is_engine = BacktestEngine(is_config)
        is_results = is_engine.run(strategy)

        # Out-of-sample
        oos_config = make_config(oos_start, oos_end)
        oos_engine = BacktestEngine(oos_config)
        oos_results = oos_engine.run(strategy)

        return WalkForwardWindow(
            window_number=window_num,
            is_start=is_start,
            is_end=is_end,
            oos_start=oos_start,
            oos_end=oos_end,
            is_results=is_results,
            oos_results=oos_results,
        )

    def run(self, strategy: BaseStrategy) -> WalkForwardReport:
        """
        Run full walk-forward validation.

        Args:
            strategy: Instantiated strategy to validate

        Returns:
            WalkForwardReport with per-window and aggregate results
        """
        log.info(
            "walk_forward_start",
            strategy=strategy.strategy_id,
            instrument=self.instrument,
            n_windows=self.n_windows,
            oos_pct=self.oos_pct,
        )

        # Load full data to determine actual date range
        data = self._downloader.load_for_backtest(
            self.instrument, self.timeframe,
            self.full_start, self.full_end,
        )

        if data.empty:
            raise ValueError(f"No data for {self.instrument} {self.timeframe}")

        actual_start = data.index[0].strftime("%Y-%m-%d")
        actual_end = data.index[-1].strftime("%Y-%m-%d")

        window_dates = self._build_windows(data)

        report = WalkForwardReport(
            strategy_id=strategy.strategy_id,
            instrument=self.instrument,
            timeframe=self.timeframe,
            full_period=f"{actual_start} → {actual_end}",
            n_windows=self.n_windows,
            oos_pct=self.oos_pct,
        )

        # Run each window
        for i, (is_start, is_end, oos_start, oos_end) in enumerate(window_dates):
            try:
                window = self._run_window(
                    strategy, is_start, is_end, oos_start, oos_end, i + 1
                )
                report.windows.append(window)
            except Exception as e:
                log.error(
                    "walk_forward_window_failed",
                    window=i + 1,
                    error=str(e),
                )

        # Aggregate OOS metrics
        self._aggregate_results(report)

        log.info(
            "walk_forward_complete",
            oos_trades=report.total_oos_trades,
            oos_return=report.oos_total_return_pct,
            verdict=report.verdict,
        )

        return report

    def _aggregate_results(self, report: WalkForwardReport) -> None:
        """Calculate aggregate metrics across all OOS windows."""
        if not report.windows:
            return

        all_oos_trades = []
        oos_returns = []
        is_returns = []
        oos_dds = []
        profitable_windows = 0

        for w in report.windows:
            oos_s = w.oos_results.summary()
            is_s = w.is_results.summary()

            n_trades = oos_s.get("total_trades", 0)
            all_oos_trades.append(n_trades)
            ret = oos_s.get("total_return_pct", 0)
            oos_returns.append(ret)
            is_returns.append(is_s.get("total_return_pct", 0))
            oos_dds.append(oos_s.get("max_drawdown_pct", 0))
            if ret > 0:
                profitable_windows += 1

        # Collect all OOS trades for combined stats
        all_trades = []
        for w in report.windows:
            all_trades.extend(w.oos_results.trades)

        report.total_oos_trades = len(all_trades)
        report.windows_profitable = profitable_windows
        report.oos_avg_return_per_window_pct = round(
            sum(oos_returns) / len(oos_returns), 2
        ) if oos_returns else 0
        report.oos_total_return_pct = round(sum(oos_returns), 2)
        report.oos_max_drawdown_pct = round(max(oos_dds) if oos_dds else 0, 2)
        report.avg_is_return_pct = round(
            sum(is_returns) / len(is_returns), 2
        ) if is_returns else 0
        report.avg_oos_return_pct = report.oos_avg_return_per_window_pct

        # Degradation: how much worse is OOS vs IS
        if report.avg_is_return_pct != 0:
            report.degradation_pct = round(
                (report.avg_oos_return_pct - report.avg_is_return_pct)
                / abs(report.avg_is_return_pct) * 100, 1
            )

        # Combined OOS stats
        if all_trades:
            pnls = [t.pnl for t in all_trades]
            wins = [t for t in all_trades if t.pnl > 0]
            losses = [t for t in all_trades if t.pnl <= 0]
            report.oos_win_rate_pct = round(len(wins) / len(all_trades) * 100, 1)
            gross_profit = sum(t.pnl for t in wins) if wins else 0
            gross_loss = abs(sum(t.pnl for t in losses)) if losses else 0.001
            report.oos_profit_factor = round(gross_profit / gross_loss, 3)

        # Verdict
        report.verdict, report.verdict_reasons = self._generate_verdict(report)

    def _generate_verdict(
        self, report: WalkForwardReport
    ) -> tuple[str, list[str]]:
        reasons = []
        fail_count = 0
        warn_count = 0

        # Profitable windows
        profitable_ratio = report.windows_profitable / max(report.n_windows, 1)
        if profitable_ratio >= 0.6:
            reasons.append(f"PASS: {report.windows_profitable}/{report.n_windows} windows profitable")
        elif profitable_ratio >= 0.4:
            reasons.append(f"WARNING: Only {report.windows_profitable}/{report.n_windows} windows profitable")
            warn_count += 1
        else:
            reasons.append(f"FAIL: Only {report.windows_profitable}/{report.n_windows} windows profitable")
            fail_count += 1

        # OOS profit factor
        if report.oos_profit_factor >= 1.3:
            reasons.append(f"PASS: OOS profit factor {report.oos_profit_factor:.3f}")
        elif report.oos_profit_factor >= 1.0:
            reasons.append(f"WARNING: OOS profit factor {report.oos_profit_factor:.3f} is marginal")
            warn_count += 1
        else:
            reasons.append(f"FAIL: OOS profit factor {report.oos_profit_factor:.3f} < 1.0")
            fail_count += 1

        # Degradation
        if report.degradation_pct > -30:
            reasons.append(f"PASS: OOS degradation {report.degradation_pct:.1f}% vs IS (acceptable)")
        elif report.degradation_pct > -60:
            reasons.append(f"WARNING: OOS degradation {report.degradation_pct:.1f}% vs IS (significant)")
            warn_count += 1
        else:
            reasons.append(f"FAIL: OOS degradation {report.degradation_pct:.1f}% vs IS (severe overfitting)")
            fail_count += 1

        # Trade count
        if report.total_oos_trades < 20:
            reasons.append(f"WARNING: Only {report.total_oos_trades} OOS trades total (need 50+)")
            warn_count += 1
        else:
            reasons.append(f"PASS: {report.total_oos_trades} OOS trades across all windows")

        verdict = "FAIL" if fail_count > 0 else "MARGINAL" if warn_count >= 2 else "MARGINAL" if warn_count == 1 else "PASS"
        return verdict, reasons

    @staticmethod
    def print_report(report: WalkForwardReport) -> None:
        width = 62
        verdict_symbols = {"PASS": "✓", "MARGINAL": "~", "FAIL": "✗"}
        symbol = verdict_symbols.get(report.verdict, "?")

        print("\n" + "═" * width)
        print(f"  WALK-FORWARD VALIDATION — {report.strategy_id}")
        print(f"  {report.instrument} {report.timeframe}  |  {report.full_period}")
        print(f"  {report.n_windows} windows  |  {int(report.oos_pct*100)}% OOS each")
        print("═" * width)

        print(f"\n  {'Window':<8} {'IS Period':<24} {'OOS Period':<24} {'OOS Trades':>10} {'OOS Return':>11}")
        print(f"  {'─'*8} {'─'*24} {'─'*24} {'─'*10} {'─'*11}")

        for w in report.windows:
            oos_s = w.oos_results.summary()
            n = oos_s.get("total_trades", 0)
            ret = oos_s.get("total_return_pct", 0)
            sign = "+" if ret >= 0 else ""
            print(f"  {w.window_number:<8} {w.is_start}→{w.is_end:<12} "
                  f"{w.oos_start}→{w.oos_end:<12} "
                  f"{n:>10} {sign}{ret:>9.2f}%")

        print(f"\n  {'AGGREGATE OOS RESULTS':}")
        print(f"  Total OOS trades      : {report.total_oos_trades}")
        print(f"  Profitable windows    : {report.windows_profitable}/{report.n_windows}")
        print(f"  OOS win rate          : {report.oos_win_rate_pct:.1f}%")
        print(f"  OOS profit factor     : {report.oos_profit_factor:.3f}")
        print(f"  OOS avg return/window : {report.oos_avg_return_per_window_pct:+.2f}%")
        print(f"  OOS total return      : {report.oos_total_return_pct:+.2f}%")
        print(f"  OOS max DD (worst)    : {report.oos_max_drawdown_pct:.2f}%")

        print(f"\n  {'IS vs OOS COMPARISON':}")
        print(f"  Avg IS return/window  : {report.avg_is_return_pct:+.2f}%")
        print(f"  Avg OOS return/window : {report.avg_oos_return_pct:+.2f}%")
        print(f"  Degradation           : {report.degradation_pct:+.1f}%")

        print(f"\n  {'─' * (width - 2)}")
        print(f"  VERDICT: {symbol} {report.verdict}")
        print(f"  {'─' * (width - 2)}")
        for reason in report.verdict_reasons:
            prefix = "  ✗ " if reason.startswith("FAIL") else "  ~ " if reason.startswith("WARNING") else "  ✓ " if reason.startswith("PASS") else "  ! "
            print(f"{prefix}{reason}")

        print(f"\n  NOTE: Walk-forward uses fixed parameters.")
        print(f"  OOS results only are used for assessment.")
        print("═" * width + "\n")
