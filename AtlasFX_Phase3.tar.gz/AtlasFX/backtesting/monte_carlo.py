"""
backtesting/monte_carlo.py
───────────────────────────
Monte Carlo robustness analysis for AtlasFX.

Takes a completed BacktestResults object and stress-tests it by:
    1. Randomly resampling the trade sequence (bootstrap)
    2. Generating N simulated equity curves
    3. Calculating probability of ruin, expected drawdown,
       confidence intervals on returns, and distribution of outcomes

This answers the key question: "Was this result skill or luck?"

A strategy with genuine edge should show:
    - Low probability of ruin (< 5%)
    - Tight confidence intervals
    - Majority of simulated paths profitable
    - Consistent max drawdown across paths

A strategy that got lucky will show:
    - Wide confidence intervals
    - Many simulated paths going bankrupt
    - High variance in outcomes

IMPORTANT: Monte Carlo resampling assumes trade independence.
If your strategy has autocorrelated trades (e.g. trend following
where wins cluster), the ruin probability will be understated.
This is a known limitation of bootstrap Monte Carlo.

Usage:
    from backtesting.monte_carlo import MonteCarlo
    mc = MonteCarlo(results, n_simulations=10000)
    report = mc.run()
    mc.print_report(report)
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Optional

import numpy as np

from backtesting.engine import BacktestResults
from logs.logger import get_logger

log = get_logger(__name__)


# ── Configuration ─────────────────────────────────────────────────────────────

@dataclass
class MonteCarloConfig:
    """Configuration for Monte Carlo analysis."""
    n_simulations: int = 10_000
    ruin_threshold_pct: float = 20.0   # Account considered "ruined" if DD exceeds this
    confidence_levels: list[float] = field(default_factory=lambda: [0.05, 0.25, 0.50, 0.75, 0.95])
    random_seed: Optional[int] = 42    # Set None for non-deterministic runs


# ── Results ───────────────────────────────────────────────────────────────────

@dataclass
class MonteCarloReport:
    """Full Monte Carlo analysis report."""
    strategy_id: str
    instrument: str
    n_trades: int
    n_simulations: int
    initial_balance: float

    # Core metrics
    probability_of_ruin_pct: float       # % of paths that hit ruin threshold
    probability_of_profit_pct: float     # % of paths that end profitable
    median_return_pct: float
    mean_return_pct: float

    # Drawdown analysis
    median_max_drawdown_pct: float
    worst_case_drawdown_pct: float       # 95th percentile drawdown
    expected_max_drawdown_pct: float     # Mean max drawdown across all paths

    # Return confidence intervals
    return_percentiles: dict[str, float]  # {p5, p25, p50, p75, p95}

    # Consecutive loss analysis
    median_max_consecutive_losses: float
    worst_case_consecutive_losses: int

    # Original backtest comparison
    original_return_pct: float
    original_win_rate_pct: float
    original_profit_factor: float

    # Verdict
    verdict: str                         # PASS | MARGINAL | FAIL
    verdict_reasons: list[str]

    # Raw data for charting
    all_final_returns: list[float] = field(default_factory=list)
    all_max_drawdowns: list[float] = field(default_factory=list)
    sample_equity_curves: list[list[float]] = field(default_factory=list)


# ── Engine ────────────────────────────────────────────────────────────────────

class MonteCarlo:
    """
    Bootstrap Monte Carlo analyser for backtest results.

    Takes a completed BacktestResults, extracts the R-multiple series,
    and runs N simulations by randomly resampling with replacement.
    """

    def __init__(
        self,
        results: BacktestResults,
        config: Optional[MonteCarloConfig] = None,
    ) -> None:
        self.results = results
        self.config = config or MonteCarloConfig()

        if len(results.trades) < 10:
            raise ValueError(
                f"Monte Carlo requires at least 10 trades. "
                f"Got {len(results.trades)}. Run a longer backtest first."
            )

        # Extract R-multiples — this is what we resample
        self.r_multiples = np.array([t.r_multiple for t in results.trades])
        self.initial_balance = results.config.initial_balance
        self.risk_pct = results.config.risk_per_trade_pct / 100

        log.info(
            "monte_carlo_initialised",
            strategy=results.strategy_id,
            trades=len(results.trades),
            n_simulations=self.config.n_simulations,
            mean_r=round(float(np.mean(self.r_multiples)), 3),
        )

    def _simulate_single_path(
        self,
        rng: np.random.Generator,
        r_multiples: np.ndarray,
    ) -> tuple[list[float], float, int]:
        """
        Simulate one equity path by applying resampled R-multiples.

        Returns:
            Tuple of (equity_curve, max_drawdown_pct, max_consecutive_losses)
        """
        n_trades = len(r_multiples)
        # Resample with replacement
        sampled_rs = rng.choice(r_multiples, size=n_trades, replace=True)

        equity = self.initial_balance
        peak = equity
        max_dd = 0.0
        equity_curve = [equity]

        max_consec_losses = 0
        current_consec = 0

        for r in sampled_rs:
            # Apply R-multiple to equity using fixed % risk
            if r > 0:
                equity *= (1 + self.risk_pct * r)
                current_consec = 0
            else:
                equity *= (1 + self.risk_pct * r)  # r is negative, so this reduces equity
                current_consec += 1
                max_consec_losses = max(max_consec_losses, current_consec)

            equity = max(equity, 0.01)  # Floor at near-zero

            if equity > peak:
                peak = equity

            dd = (peak - equity) / peak * 100
            if dd > max_dd:
                max_dd = dd

            equity_curve.append(equity)

        return equity_curve, max_dd, max_consec_losses

    def run(self) -> MonteCarloReport:
        """
        Run the full Monte Carlo analysis.

        Returns:
            MonteCarloReport with all statistics and verdict.
        """
        log.info(
            "monte_carlo_start",
            n_simulations=self.config.n_simulations,
            strategy=self.results.strategy_id,
        )

        rng = np.random.default_rng(self.config.random_seed)

        final_returns: list[float] = []
        max_drawdowns: list[float] = []
        consecutive_losses: list[int] = []
        sample_curves: list[list[float]] = []
        ruin_count = 0

        ruin_threshold = self.initial_balance * (1 - self.config.ruin_threshold_pct / 100)

        # Run simulations
        for i in range(self.config.n_simulations):
            curve, max_dd, max_consec = self._simulate_single_path(rng, self.r_multiples)

            final_equity = curve[-1]
            final_return_pct = (final_equity / self.initial_balance - 1) * 100

            final_returns.append(final_return_pct)
            max_drawdowns.append(max_dd)
            consecutive_losses.append(max_consec)

            if final_equity <= ruin_threshold or max_dd >= self.config.ruin_threshold_pct:
                ruin_count += 1

            # Store 50 sample curves for charting
            if i < 50:
                sample_curves.append(curve)

        # Convert to numpy for fast stats
        returns_arr = np.array(final_returns)
        dd_arr = np.array(max_drawdowns)
        consec_arr = np.array(consecutive_losses)

        # Calculate percentiles
        percentile_values = np.percentile(returns_arr, [5, 25, 50, 75, 95])
        return_percentiles = {
            "p5":  round(float(percentile_values[0]), 2),
            "p25": round(float(percentile_values[1]), 2),
            "p50": round(float(percentile_values[2]), 2),
            "p75": round(float(percentile_values[3]), 2),
            "p95": round(float(percentile_values[4]), 2),
        }

        probability_of_ruin = ruin_count / self.config.n_simulations * 100
        probability_of_profit = float(np.sum(returns_arr > 0)) / self.config.n_simulations * 100

        # Original backtest stats
        orig_summary = self.results.summary()

        # Generate verdict
        verdict, reasons = self._generate_verdict(
            probability_of_ruin=probability_of_ruin,
            probability_of_profit=probability_of_profit,
            median_return=float(np.median(returns_arr)),
            worst_dd=float(np.percentile(dd_arr, 95)),
            orig_win_rate=orig_summary.get("win_rate_pct", 0),
            orig_profit_factor=orig_summary.get("profit_factor", 0),
            n_trades=len(self.results.trades),
        )

        report = MonteCarloReport(
            strategy_id=self.results.strategy_id,
            instrument=self.results.config.instrument,
            n_trades=len(self.results.trades),
            n_simulations=self.config.n_simulations,
            initial_balance=self.initial_balance,
            probability_of_ruin_pct=round(probability_of_ruin, 2),
            probability_of_profit_pct=round(probability_of_profit, 2),
            median_return_pct=round(float(np.median(returns_arr)), 2),
            mean_return_pct=round(float(np.mean(returns_arr)), 2),
            median_max_drawdown_pct=round(float(np.median(dd_arr)), 2),
            worst_case_drawdown_pct=round(float(np.percentile(dd_arr, 95)), 2),
            expected_max_drawdown_pct=round(float(np.mean(dd_arr)), 2),
            return_percentiles=return_percentiles,
            median_max_consecutive_losses=round(float(np.median(consec_arr)), 1),
            worst_case_consecutive_losses=int(np.percentile(consec_arr, 95)),
            original_return_pct=round(orig_summary.get("total_return_pct", 0), 2),
            original_win_rate_pct=round(orig_summary.get("win_rate_pct", 0), 2),
            original_profit_factor=round(orig_summary.get("profit_factor", 0), 3),
            verdict=verdict,
            verdict_reasons=reasons,
            all_final_returns=final_returns,
            all_max_drawdowns=list(max_drawdowns),
            sample_equity_curves=sample_curves,
        )

        log.info(
            "monte_carlo_complete",
            ruin_pct=report.probability_of_ruin_pct,
            profit_pct=report.probability_of_profit_pct,
            median_return=report.median_return_pct,
            verdict=verdict,
        )

        return report

    def _generate_verdict(
        self,
        probability_of_ruin: float,
        probability_of_profit: float,
        median_return: float,
        worst_dd: float,
        orig_win_rate: float,
        orig_profit_factor: float,
        n_trades: int,
    ) -> tuple[str, list[str]]:
        """
        Generate a PASS / MARGINAL / FAIL verdict with reasons.

        Criteria:
            PASS:     ruin < 5%, profit > 60%, median return > 0, n_trades >= 50
            MARGINAL: ruin < 15%, profit > 45%, or n_trades < 50
            FAIL:     ruin >= 15%, or profit <= 45%, or median return < 0
        """
        reasons = []
        fail_count = 0
        warn_count = 0

        # Sample size
        if n_trades < 30:
            reasons.append(f"INSUFFICIENT SAMPLE: {n_trades} trades (minimum 30 for any conclusion, 200+ recommended)")
            fail_count += 1
        elif n_trades < 100:
            reasons.append(f"SMALL SAMPLE: {n_trades} trades — results have wide confidence intervals")
            warn_count += 1
        else:
            reasons.append(f"Sample size: {n_trades} trades ({'adequate' if n_trades >= 200 else 'borderline'})")

        # Ruin probability
        if probability_of_ruin >= 15:
            reasons.append(f"FAIL: Ruin probability {probability_of_ruin:.1f}% is too high (limit: 15%)")
            fail_count += 1
        elif probability_of_ruin >= 5:
            reasons.append(f"WARNING: Ruin probability {probability_of_ruin:.1f}% is elevated (target: < 5%)")
            warn_count += 1
        else:
            reasons.append(f"PASS: Ruin probability {probability_of_ruin:.1f}% is acceptable (< 5%)")

        # Profit probability
        if probability_of_profit <= 45:
            reasons.append(f"FAIL: Only {probability_of_profit:.1f}% of paths are profitable (minimum: 45%)")
            fail_count += 1
        elif probability_of_profit <= 60:
            reasons.append(f"WARNING: {probability_of_profit:.1f}% of paths profitable (target: > 60%)")
            warn_count += 1
        else:
            reasons.append(f"PASS: {probability_of_profit:.1f}% of paths are profitable")

        # Median return
        if median_return < 0:
            reasons.append(f"FAIL: Median return {median_return:.2f}% is negative")
            fail_count += 1
        elif median_return < 1:
            reasons.append(f"WARNING: Median return {median_return:.2f}% is marginally positive")
            warn_count += 1
        else:
            reasons.append(f"PASS: Median return {median_return:.2f}% is positive")

        # Worst-case drawdown
        if worst_dd >= 30:
            reasons.append(f"FAIL: 95th percentile drawdown {worst_dd:.1f}% is too severe")
            fail_count += 1
        elif worst_dd >= 20:
            reasons.append(f"WARNING: 95th percentile drawdown {worst_dd:.1f}% is significant")
            warn_count += 1
        else:
            reasons.append(f"PASS: 95th percentile drawdown {worst_dd:.1f}% is acceptable")

        # Profit factor
        if orig_profit_factor < 1.0:
            reasons.append(f"FAIL: Original profit factor {orig_profit_factor:.3f} < 1.0 (losing strategy)")
            fail_count += 1
        elif orig_profit_factor < 1.3:
            reasons.append(f"WARNING: Profit factor {orig_profit_factor:.3f} is marginal (target: > 1.3)")
            warn_count += 1
        else:
            reasons.append(f"PASS: Profit factor {orig_profit_factor:.3f} shows positive edge")

        # Verdict
        if fail_count > 0:
            verdict = "FAIL"
        elif warn_count >= 2:
            verdict = "MARGINAL"
        elif warn_count == 1:
            verdict = "MARGINAL"
        else:
            verdict = "PASS"

        return verdict, reasons

    @staticmethod
    def print_report(report: MonteCarloReport) -> None:
        """Print a formatted Monte Carlo report to console."""
        width = 62

        verdict_symbols = {"PASS": "✓", "MARGINAL": "~", "FAIL": "✗"}
        symbol = verdict_symbols.get(report.verdict, "?")

        print("\n" + "═" * width)
        print(f"  MONTE CARLO ANALYSIS — {report.strategy_id}")
        print(f"  {report.instrument}  |  {report.n_simulations:,} simulations  |  {report.n_trades} trades")
        print("═" * width)

        print(f"\n  {'ORIGINAL BACKTEST':}")
        print(f"  Return          : {report.original_return_pct:+.2f}%")
        print(f"  Win rate        : {report.original_win_rate_pct:.1f}%")
        print(f"  Profit factor   : {report.original_profit_factor:.3f}")

        print(f"\n  {'MONTE CARLO RESULTS':}")
        print(f"  Probability of ruin   : {report.probability_of_ruin_pct:.2f}%")
        print(f"  Probability of profit : {report.probability_of_profit_pct:.1f}%")
        print(f"  Median return         : {report.median_return_pct:+.2f}%")
        print(f"  Mean return           : {report.mean_return_pct:+.2f}%")

        print(f"\n  {'RETURN DISTRIBUTION (percentiles)':}")
        p = report.return_percentiles
        print(f"  Worst 5%   (p5)  : {p['p5']:+.2f}%")
        print(f"  Lower 25%  (p25) : {p['p25']:+.2f}%")
        print(f"  Median     (p50) : {p['p50']:+.2f}%")
        print(f"  Upper 75%  (p75) : {p['p75']:+.2f}%")
        print(f"  Best 5%    (p95) : {p['p95']:+.2f}%")

        print(f"\n  {'DRAWDOWN ANALYSIS':}")
        print(f"  Median max DD         : {report.median_max_drawdown_pct:.2f}%")
        print(f"  Expected max DD       : {report.expected_max_drawdown_pct:.2f}%")
        print(f"  Worst case (95th pct) : {report.worst_case_drawdown_pct:.2f}%")

        print(f"\n  {'CONSECUTIVE LOSSES':}")
        print(f"  Median max streak     : {report.median_max_consecutive_losses:.0f}")
        print(f"  Worst case (95th pct) : {report.worst_case_consecutive_losses}")

        print(f"\n  {'─' * (width - 2)}")
        print(f"  VERDICT: {symbol} {report.verdict}")
        print(f"  {'─' * (width - 2)}")
        for reason in report.verdict_reasons:
            prefix = "  ✗ " if reason.startswith("FAIL") else "  ~ " if reason.startswith("WARNING") else "  ✓ " if reason.startswith("PASS") else "  ! "
            print(f"{prefix}{reason}")

        print(f"\n  NOTE: Monte Carlo assumes trade independence.")
        print(f"  Results are simulated estimates, not guarantees.")
        print("═" * width + "\n")
