"""
logs/logger.py
──────────────
AtlasFX structured logging system.

Provides a factory function that creates consistent loggers across all modules.
Uses structlog for structured output. In development: human-readable coloured
console output. In production: JSON output for log aggregation.

Usage:
    from logs.logger import get_logger
    log = get_logger(__name__)
    log.info("trade_opened", instrument="EUR_USD", direction="BUY", price=1.0850)
    log.error("broker_error", error=str(e), order_id="12345")
"""

from __future__ import annotations

import logging
import sys
from pathlib import Path
from typing import Any

import structlog

# ── Paths ─────────────────────────────────────────────────────────────────────
_PROJECT_ROOT = Path(__file__).resolve().parent.parent
_LOG_DIR = _PROJECT_ROOT / "logs"
_LOG_DIR.mkdir(exist_ok=True)


def configure_logging(log_level: str = "INFO", environment: str = "development") -> None:
    """
    Configure structlog for the application.

    Call this once at application startup (e.g. in main entry points).
    Multiple calls are safe — subsequent calls are no-ops unless force=True.

    Args:
        log_level: One of DEBUG, INFO, WARNING, ERROR.
        environment: 'development' for human-readable, 'production' for JSON.
    """
    level = getattr(logging, log_level.upper(), logging.INFO)

    # ── Shared processors ─────────────────────────────────────
    shared_processors: list[Any] = [
        structlog.contextvars.merge_contextvars,
        structlog.stdlib.add_logger_name,
        structlog.stdlib.add_log_level,
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.ExceptionPrettyPrinter() if environment == "development"
        else structlog.processors.format_exc_info,
    ]

    if environment == "production":
        # JSON output for log aggregation
        renderer = structlog.processors.JSONRenderer()
    else:
        # Colourised console output for development
        renderer = structlog.dev.ConsoleRenderer(colors=True)

    structlog.configure(
        processors=shared_processors + [
            structlog.stdlib.ProcessorFormatter.wrap_for_formatter,
        ],
        logger_factory=structlog.stdlib.LoggerFactory(),
        wrapper_class=structlog.stdlib.BoundLogger,
        cache_logger_on_first_use=True,
    )

    formatter = structlog.stdlib.ProcessorFormatter(
        processor=renderer,
        foreign_pre_chain=shared_processors,
    )

    # ── Console handler ───────────────────────────────────────
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(formatter)

    # ── File handler — daily rotation ─────────────────────────
    import logging.handlers
    file_handler = logging.handlers.TimedRotatingFileHandler(
        filename=_LOG_DIR / "atlasfx.log",
        when="midnight",
        backupCount=30,
        encoding="utf-8",
    )
    file_handler.setFormatter(formatter)

    # ── Error file handler ────────────────────────────────────
    error_handler = logging.handlers.TimedRotatingFileHandler(
        filename=_LOG_DIR / "atlasfx_errors.log",
        when="midnight",
        backupCount=90,
        encoding="utf-8",
    )
    error_handler.setLevel(logging.ERROR)
    error_handler.setFormatter(formatter)

    # ── Root logger ───────────────────────────────────────────
    root_logger = logging.getLogger()
    root_logger.setLevel(level)
    # Remove existing handlers to avoid duplication
    root_logger.handlers.clear()
    root_logger.addHandler(console_handler)
    root_logger.addHandler(file_handler)
    root_logger.addHandler(error_handler)

    # ── Silence noisy third-party loggers ─────────────────────
    logging.getLogger("urllib3").setLevel(logging.WARNING)
    logging.getLogger("asyncio").setLevel(logging.WARNING)
    logging.getLogger("aiohttp").setLevel(logging.WARNING)


def get_logger(name: str) -> structlog.stdlib.BoundLogger:
    """
    Return a bound structlog logger for the given module name.

    Args:
        name: Typically __name__ of the calling module.

    Returns:
        A structlog BoundLogger with the module name bound.

    Example:
        log = get_logger(__name__)
        log.info("engine_started", strategy="ICT_Silver_Bullet")
    """
    return structlog.get_logger(name)


# ── Trade-specific logging helpers ────────────────────────────────────────────

def log_trade_open(
    logger: structlog.stdlib.BoundLogger,
    *,
    instrument: str,
    direction: str,
    entry_price: float,
    stop_loss: float,
    take_profit: float,
    lot_size: float,
    strategy_id: str,
    order_id: str | None = None,
    is_paper: bool = False,
) -> None:
    """Standardised log entry for trade opening."""
    rr = abs(take_profit - entry_price) / abs(stop_loss - entry_price) if stop_loss != entry_price else 0
    logger.info(
        "trade_opened",
        instrument=instrument,
        direction=direction,
        entry_price=entry_price,
        stop_loss=stop_loss,
        take_profit=take_profit,
        lot_size=lot_size,
        risk_reward=round(rr, 2),
        strategy_id=strategy_id,
        order_id=order_id,
        paper=is_paper,
    )


def log_trade_close(
    logger: structlog.stdlib.BoundLogger,
    *,
    instrument: str,
    direction: str,
    entry_price: float,
    exit_price: float,
    lot_size: float,
    pnl: float,
    r_multiple: float,
    strategy_id: str,
    order_id: str | None = None,
    close_reason: str = "target",
    is_paper: bool = False,
) -> None:
    """Standardised log entry for trade closure."""
    logger.info(
        "trade_closed",
        instrument=instrument,
        direction=direction,
        entry_price=entry_price,
        exit_price=exit_price,
        lot_size=lot_size,
        pnl=round(pnl, 2),
        r_multiple=round(r_multiple, 2),
        strategy_id=strategy_id,
        order_id=order_id,
        close_reason=close_reason,
        paper=is_paper,
    )


def log_risk_event(
    logger: structlog.stdlib.BoundLogger,
    *,
    event_type: str,
    current_value: float,
    limit_value: float,
    action_taken: str,
) -> None:
    """Log a risk management event."""
    logger.warning(
        "risk_event",
        event_type=event_type,
        current_value=round(current_value, 4),
        limit_value=round(limit_value, 4),
        action_taken=action_taken,
    )
