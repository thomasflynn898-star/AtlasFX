"""AtlasFX data package."""
