#!/usr/bin/env python3
"""
scripts/connect_oanda.py
─────────────────────────
Test and verify OANDA API connection.

Run this after adding your OANDA credentials to .env to confirm
the connection works before proceeding to live data or trading.

Usage:
    python scripts/connect_oanda.py
    python scripts/connect_oanda.py --fetch-candles EUR_USD H4 200
    python scripts/connect_oanda.py --account
"""

import argparse
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from logs.logger import configure_logging, get_logger

configure_logging(log_level="INFO", environment="development")
log = get_logger("connect_oanda")


def get_broker():
    """Build OANDA broker from .env credentials."""
    from config.settings import settings
    from broker.oanda import OANDABroker

    if not settings.oanda_api_key:
        print("\n✗ OANDA_API_KEY not set in .env")
        print("  1. Open a free practice account at https://www.oanda.com")
        print("  2. Go to My Account → Manage API Access")
        print("  3. Generate a token and add to .env:\n")
        print("     OANDA_API_KEY=your-token-here")
        print("     OANDA_ACCOUNT_ID=your-account-id")
        print("     OANDA_ENVIRONMENT=practice\n")
        sys.exit(1)

    return OANDABroker(
        api_key=settings.oanda_api_key,
        account_id=settings.oanda_account_id,
        environment=settings.oanda_environment.value,
    )


def test_connection(broker):
    print("\n── Connection Test ───────────────────────────────────")
    ok = broker.test_connection()
    if ok:
        print("  ✓ Connected to OANDA API successfully")
    else:
        print("  ✗ Connection failed — check API key and account ID")
        sys.exit(1)


def show_account(broker):
    print("\n── Account Summary ───────────────────────────────────")
    acct = broker.get_account()
    print(f"  Account ID    : {acct.account_id}")
    print(f"  Currency      : {acct.currency}")
    print(f"  Balance       : {acct.balance:,.2f}")
    print(f"  NAV           : {acct.nav:,.2f}")
    print(f"  Unrealised P&L: {acct.unrealised_pnl:+,.2f}")
    print(f"  Margin used   : {acct.margin_used:,.2f}")
    print(f"  Open trades   : {acct.open_trade_count}")


def show_prices(broker):
    print("\n── Live Prices ───────────────────────────────────────")
    instruments = ["EUR_USD", "GBP_USD", "USD_JPY", "XAU_USD"]
    for inst in instruments:
        try:
            price = broker.get_price(inst)
            spread_pips = price.spread / (0.01 if "JPY" in inst or "XAU" in inst else 0.0001)
            print(f"  {inst:<10} Bid: {price.bid:.5f}  Ask: {price.ask:.5f}  "
                  f"Spread: {spread_pips:.1f} pips")
        except Exception as e:
            print(f"  {inst:<10} Error: {e}")


def fetch_candles(broker, instrument, granularity, count):
    print(f"\n── Candles: {instrument} {granularity} (last {count}) ────────────────")
    try:
        df = broker.get_candles_as_dataframe(instrument, granularity, count)
        if df.empty:
            print("  No data returned")
            return
        print(f"  Bars fetched  : {len(df)}")
        print(f"  First bar     : {df.index[0]}")
        print(f"  Last bar      : {df.index[-1]}")
        print(f"  Last close    : {df['Close'].iloc[-1]:.5f}")
        print(f"\n  Last 5 bars:")
        print(df.tail(5).to_string())

        # Save to historical cache
        import pandas as pd
        from config.settings import settings
        path = settings.data_historical_path / instrument / f"{granularity}.parquet"
        path.parent.mkdir(parents=True, exist_ok=True)

        # Merge with existing if present
        if path.exists():
            existing = pd.read_parquet(path)
            combined = pd.concat([existing, df])
            combined = combined[~combined.index.duplicated(keep="last")]
            combined.sort_index(inplace=True)
            combined.to_parquet(path)
            print(f"\n  ✓ Merged with existing cache: {len(combined)} total bars")
        else:
            df.to_parquet(path)
            print(f"\n  ✓ Saved to cache: {path}")

    except Exception as e:
        print(f"  ✗ Error: {e}")
        import traceback
        traceback.print_exc()


def main():
    parser = argparse.ArgumentParser(description="AtlasFX OANDA Connection Tool")
    parser.add_argument("--account", action="store_true", help="Show account summary")
    parser.add_argument("--prices", action="store_true", help="Show live prices")
    parser.add_argument("--fetch-candles", nargs=3, metavar=("INSTRUMENT", "GRANULARITY", "COUNT"),
                        help="Fetch candles e.g. --fetch-candles EUR_USD H4 500")
    parser.add_argument("--download-all", action="store_true",
                        help="Download H4 and H1 data for all instruments")
    args = parser.parse_args()

    broker = get_broker()
    test_connection(broker)
    show_account(broker)

    if args.prices or not any([args.account, args.fetch_candles, args.download_all]):
        show_prices(broker)

    if args.fetch_candles:
        instrument, granularity, count = args.fetch_candles
        fetch_candles(broker, instrument, granularity, int(count))

    if args.download_all:
        print("\n── Downloading H4 + D data for all instruments ──────")
        instruments = ["EUR_USD", "GBP_USD", "USD_JPY", "XAU_USD"]
        for inst in instruments:
            for tf in ["H4", "H1", "D"]:
                count = 5000 if tf == "H4" else 2000 if tf == "H1" else 5000
                print(f"  Fetching {inst} {tf}...")
                fetch_candles(broker, inst, tf, count)

    print("\n✓ OANDA connection verified. Ready for Phase 5 (paper trading agent).\n")


if __name__ == "__main__":
    main()
