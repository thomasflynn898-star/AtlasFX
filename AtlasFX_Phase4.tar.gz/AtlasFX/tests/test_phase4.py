"""
tests/test_phase4.py
─────────────────────
Tests for broker abstraction layer and execution engine.

Uses mocks throughout — no real broker connection required.
Tests verify the execution engine's safety gates work correctly.
"""

import sys
from datetime import datetime
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from broker.base import AccountInfo, OpenTrade, OrderResult, Price
from broker.oanda import OANDABroker
from execution.engine import ExecutionConfig, ExecutionEngine
from risk.engine import RiskCheckResult, RiskEngine
from strategies.base import TradeSignal


# ── Fixtures ──────────────────────────────────────────────────────────────────

def make_signal(direction="BUY", instrument="EUR_USD") -> TradeSignal:
    if direction == "BUY":
        return TradeSignal(
            strategy_id="TEST_V1", instrument=instrument,
            direction="BUY", entry_price=1.0850,
            stop_loss=1.0820, take_profit=1.0910,
            confidence=0.75, timeframe="H1",
            timestamp=datetime.utcnow(),
        )
    else:
        return TradeSignal(
            strategy_id="TEST_V1", instrument=instrument,
            direction="SELL", entry_price=1.0850,
            stop_loss=1.0880, take_profit=1.0790,
            confidence=0.70, timeframe="H1",
            timestamp=datetime.utcnow(),
        )


def make_approved_risk_result(units=10000, risk_amount=50.0) -> RiskCheckResult:
    return RiskCheckResult(
        approved=True, reason="All checks passed",
        risk_amount=risk_amount, lot_size=units,
        adjusted_risk_pct=0.5,
    )


def make_rejected_risk_result() -> RiskCheckResult:
    return RiskCheckResult(
        approved=False, reason="Daily drawdown limit hit",
    )


def make_mock_broker(
    balance=10000.0,
    bid=1.08495,
    ask=1.08505,
    order_success=True,
) -> MagicMock:
    broker = MagicMock()
    broker.name = "Mock Broker"
    broker.is_connected = True

    broker.get_account.return_value = AccountInfo(
        account_id="TEST123", balance=balance, nav=balance,
        unrealised_pnl=0.0, margin_used=0.0,
        margin_available=balance, currency="USD",
        open_trade_count=0,
    )
    broker.get_price.return_value = Price(
        instrument="EUR_USD", bid=bid, ask=ask,
        timestamp=datetime.utcnow(),
    )

    if order_success:
        broker.submit_market_order.return_value = OrderResult(
            success=True, order_id="ORD_123", trade_id="TRD_456",
            instrument="EUR_USD", direction="BUY",
            units=10000, entry_price=ask,
            stop_loss=1.0820, take_profit=1.0910,
        )
    else:
        broker.submit_market_order.return_value = OrderResult(
            success=False, order_id=None, trade_id=None,
            instrument="EUR_USD", direction="BUY",
            units=10000, entry_price=0,
            stop_loss=1.0820, take_profit=1.0910,
            error_message="Insufficient margin",
        )

    return broker


# ── OANDA Broker Tests (unit — no real API) ───────────────────────────────────

class TestOANDABrokerInit:
    def test_requires_api_key(self):
        with pytest.raises(ValueError, match="API key"):
            OANDABroker(api_key="", account_id="123")

    def test_requires_account_id(self):
        with pytest.raises(ValueError, match="account ID"):
            OANDABroker(api_key="key123", account_id="")

    def test_rejects_invalid_environment(self):
        with pytest.raises(ValueError, match="environment"):
            OANDABroker(api_key="key", account_id="id", environment="staging")

    def test_practice_url(self):
        broker = OANDABroker(api_key="key", account_id="id", environment="practice")
        assert "fxpractice" in broker._base_url

    def test_live_url(self):
        broker = OANDABroker(api_key="key", account_id="id", environment="live")
        assert "fxtrade" in broker._base_url

    def test_name_includes_environment(self):
        broker = OANDABroker(api_key="key", account_id="id", environment="practice")
        assert "practice" in broker.name.lower()


class TestOANDABrokerAPI:
    """Tests that mock the HTTP layer."""

    def test_get_account_parses_response(self):
        broker = OANDABroker(api_key="key", account_id="001-123", environment="practice")
        mock_response = {
            "account": {
                "id": "001-123", "balance": "10000.00", "NAV": "10050.00",
                "unrealizedPL": "50.00", "marginUsed": "100.00",
                "marginAvailable": "9900.00", "currency": "USD",
                "openTradeCount": 2,
            }
        }
        with patch.object(broker, "_request", return_value=mock_response):
            acct = broker.get_account()
        assert acct.balance == 10000.0
        assert acct.nav == 10050.0
        assert acct.currency == "USD"
        assert acct.open_trade_count == 2

    def test_get_price_parses_response(self):
        broker = OANDABroker(api_key="key", account_id="001-123", environment="practice")
        mock_response = {
            "prices": [{
                "instrument": "EUR_USD",
                "bids": [{"price": "1.08450", "liquidity": 10000000}],
                "asks": [{"price": "1.08460", "liquidity": 10000000}],
                "time": "2024-01-15T10:00:00.000000Z",
            }]
        }
        with patch.object(broker, "_request", return_value=mock_response):
            price = broker.get_price("EUR_USD")
        assert price.bid == 1.08450
        assert price.ask == 1.08460
        assert abs(price.spread - 0.0001) < 0.000001

    def test_submit_order_builds_correct_body(self):
        broker = OANDABroker(api_key="key", account_id="001-123", environment="practice")
        mock_response = {
            "orderFillTransaction": {
                "price": "1.08460", "orderID": "ORD_1",
                "tradeOpened": {"tradeID": "TRD_1"},
            }
        }
        captured_body = {}
        def capture_request(method, endpoint, params=None, json=None):
            captured_body.update(json or {})
            return mock_response

        with patch.object(broker, "_request", side_effect=capture_request):
            result = broker.submit_market_order(
                "EUR_USD", "BUY", 10000, 1.0820, 1.0910
            )

        assert result.success is True
        order = captured_body["order"]
        assert order["units"] == "10000"        # BUY = positive
        assert order["type"] == "MARKET"
        assert "stopLossOnFill" in order
        assert "takeProfitOnFill" in order

    def test_submit_sell_uses_negative_units(self):
        broker = OANDABroker(api_key="key", account_id="001-123", environment="practice")
        mock_response = {
            "orderFillTransaction": {
                "price": "1.08450", "orderID": "ORD_2",
                "tradeOpened": {"tradeID": "TRD_2"},
            }
        }
        captured_body = {}
        def capture_request(method, endpoint, params=None, json=None):
            captured_body.update(json or {})
            return mock_response

        with patch.object(broker, "_request", side_effect=capture_request):
            broker.submit_market_order("EUR_USD", "SELL", 5000, 1.0880, 1.0790)

        assert captured_body["order"]["units"] == "-5000"  # SELL = negative

    def test_get_candles_filters_incomplete(self):
        broker = OANDABroker(api_key="key", account_id="001-123", environment="practice")
        mock_response = {
            "candles": [
                {"time": "2024-01-01T00:00:00Z", "complete": True,
                 "mid": {"o":"1.100","h":"1.105","l":"1.099","c":"1.103"}, "volume": 100},
                {"time": "2024-01-01T01:00:00Z", "complete": False,  # incomplete — skip
                 "mid": {"o":"1.103","h":"1.107","l":"1.102","c":"1.106"}, "volume": 50},
            ]
        }
        with patch.object(broker, "_request", return_value=mock_response):
            candles = broker.get_candles("EUR_USD", "H1", 2)
        assert len(candles) == 1  # Only complete candle
        assert candles[0]["close"] == 1.103


# ── Execution Engine Tests ────────────────────────────────────────────────────

class TestExecutionEnginePaperMode:
    """Test execution engine in paper mode (default/safe)."""

    def test_paper_mode_by_default(self):
        broker = make_mock_broker()
        risk = RiskEngine(account_balance=10000.0)
        engine = ExecutionEngine(broker, risk)
        assert engine._config.is_paper_mode is True

    def test_approved_signal_executes_in_paper(self):
        broker = make_mock_broker()
        risk = RiskEngine(account_balance=10000.0)
        engine = ExecutionEngine(broker, risk, ExecutionConfig(is_paper_mode=True))
        signal = make_signal()
        risk_result = make_approved_risk_result()
        result = engine.execute(signal, risk_result)
        assert result.success is True
        assert result.is_paper is True
        assert result.order_result.trade_id.startswith("PAPER_")

    def test_rejected_risk_not_executed(self):
        broker = make_mock_broker()
        risk = RiskEngine(account_balance=10000.0)
        engine = ExecutionEngine(broker, risk, ExecutionConfig(is_paper_mode=True))
        signal = make_signal()
        risk_result = make_rejected_risk_result()
        result = engine.execute(signal, risk_result)
        assert result.success is False
        assert "Risk check failed" in result.rejection_reason
        broker.submit_market_order.assert_not_called()

    def test_wide_spread_rejected(self):
        broker = make_mock_broker(bid=1.0840, ask=1.0855)  # 1.5 pip spread
        risk = RiskEngine(account_balance=10000.0)
        config = ExecutionConfig(is_paper_mode=True, max_spread_pips=1.0)
        engine = ExecutionEngine(broker, risk, config)
        signal = make_signal()
        risk_result = make_approved_risk_result()
        result = engine.execute(signal, risk_result)
        assert result.success is False
        assert "spread" in result.rejection_reason.lower()

    def test_tight_spread_accepted(self):
        broker = make_mock_broker(bid=1.08495, ask=1.08505)  # 0.1 pip spread
        risk = RiskEngine(account_balance=10000.0)
        config = ExecutionConfig(is_paper_mode=True, max_spread_pips=3.0)
        engine = ExecutionEngine(broker, risk, config)
        signal = make_signal()
        risk_result = make_approved_risk_result()
        result = engine.execute(signal, risk_result)
        assert result.success is True

    def test_low_balance_rejected(self):
        broker = make_mock_broker(balance=50.0)  # Below minimum
        risk = RiskEngine(account_balance=50.0)
        config = ExecutionConfig(is_paper_mode=True, min_account_balance=100.0)
        engine = ExecutionEngine(broker, risk, config)
        signal = make_signal()
        risk_result = make_approved_risk_result()
        result = engine.execute(signal, risk_result)
        assert result.success is False
        assert "balance" in result.rejection_reason.lower()

    def test_paper_does_not_call_broker_submit(self):
        broker = make_mock_broker()
        risk = RiskEngine(account_balance=10000.0)
        engine = ExecutionEngine(broker, risk, ExecutionConfig(is_paper_mode=True))
        signal = make_signal()
        risk_result = make_approved_risk_result()
        engine.execute(signal, risk_result)
        broker.submit_market_order.assert_not_called()

    def test_broker_api_error_handled(self):
        broker = make_mock_broker()
        broker.get_account.side_effect = Exception("Network timeout")
        risk = RiskEngine(account_balance=10000.0)
        engine = ExecutionEngine(broker, risk, ExecutionConfig(is_paper_mode=True))
        signal = make_signal()
        risk_result = make_approved_risk_result()
        result = engine.execute(signal, risk_result)
        assert result.success is False
        assert "account info" in result.rejection_reason.lower()

    def test_sell_signal_paper_executes(self):
        broker = make_mock_broker()
        risk = RiskEngine(account_balance=10000.0)
        engine = ExecutionEngine(broker, risk, ExecutionConfig(is_paper_mode=True))
        signal = make_signal(direction="SELL")
        risk_result = make_approved_risk_result()
        result = engine.execute(signal, risk_result)
        assert result.success is True
        assert result.order_result.direction == "SELL"

    def test_xau_spread_calculated_correctly(self):
        """XAU spread should use 0.01 pip size."""
        broker = make_mock_broker(bid=2000.0, ask=2000.5)
        broker.get_price.return_value = Price(
            instrument="XAU_USD", bid=2000.0, ask=2000.5,
            timestamp=datetime.utcnow(),
        )
        risk = RiskEngine(account_balance=10000.0)
        config = ExecutionConfig(is_paper_mode=True, max_spread_pips=100.0)
        engine = ExecutionEngine(broker, risk, config)
        signal = TradeSignal(
            strategy_id="TEST", instrument="XAU_USD",
            direction="BUY", entry_price=2000.5,
            stop_loss=1990.0, take_profit=2020.0,
            confidence=0.7, timeframe="D",
            timestamp=datetime.utcnow(),
        )
        result = engine.execute(signal, make_approved_risk_result())
        assert result.live_spread_pips == pytest.approx(50.0, abs=1.0)
