"""
execution/engine.py
────────────────────
AtlasFX execution engine.

The execution engine sits between the risk engine and the broker.
It receives an approved TradeSignal + RiskCheckResult, performs
final pre-flight checks, submits the order to the broker, and
records the result.

Responsibility chain:
    Strategy → Signal → Risk Engine → Execution Engine → Broker → Journal

The execution engine handles:
    - Spread verification against live price
    - News filter (basic — no trading 5 min before/after major news)
    - Final lot size calculation using live account balance
    - Order submission via broker adapter
    - Retry logic on transient failures
    - Full logging of every action

The execution engine does NOT:
    - Generate signals
    - Calculate risk (risk engine does that)
    - Store trade data permanently (journal does that)

IMPORTANT: This module controls real money when connected to a live
broker. Every change must be reviewed carefully.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Optional

from broker.base import BaseBroker, OrderResult
from logs.logger import get_logger, log_trade_open
from risk.engine import RiskCheckResult, RiskEngine
from strategies.base import TradeSignal

log = get_logger(__name__)


@dataclass
class ExecutionConfig:
    """
    Configuration for the execution engine.

    All safety limits are enforced here regardless of
    what the risk engine approves.
    """
    max_spread_pips: float = 3.0          # Reject if spread exceeds this
    max_slippage_pips: float = 2.0        # Warn if fill price deviates
    retry_on_failure: bool = True
    max_retries: int = 2
    retry_delay_seconds: float = 1.0
    is_paper_mode: bool = True            # SAFETY: default to paper mode
    min_account_balance: float = 100.0   # Halt if balance drops below this


@dataclass
class ExecutionResult:
    """Result of attempting to execute a trade signal."""
    success: bool
    signal: TradeSignal
    order_result: Optional[OrderResult]
    rejection_reason: Optional[str]
    is_paper: bool
    executed_at: datetime
    live_spread_pips: float = 0.0
    live_bid: float = 0.0
    live_ask: float = 0.0


class ExecutionEngine:
    """
    Executes approved trade signals via the broker adapter.

    Safety gates (in order):
        1. Paper mode check — will not submit live if is_paper_mode=True
        2. Account balance minimum check
        3. Live spread check — reject if wider than config
        4. Price sanity check — signal price vs live price
        5. Order submission with retry
        6. Fill price slippage check (post-fill warning)

    Usage:
        engine = ExecutionEngine(broker, risk_engine, config)
        result = engine.execute(signal, risk_result)
    """

    def __init__(
        self,
        broker: BaseBroker,
        risk_engine: RiskEngine,
        config: Optional[ExecutionConfig] = None,
    ) -> None:
        self._broker = broker
        self._risk_engine = risk_engine
        self._config = config or ExecutionConfig()

        if not self._config.is_paper_mode:
            log.warning(
                "execution_engine_live_mode",
                message="LIVE MODE ENABLED — orders will be submitted to broker",
            )
        else:
            log.info("execution_engine_paper_mode")

    def execute(
        self,
        signal: TradeSignal,
        risk_result: RiskCheckResult,
    ) -> ExecutionResult:
        """
        Attempt to execute an approved trade signal.

        Args:
            signal: The trade signal to execute
            risk_result: Pre-approved risk check result

        Returns:
            ExecutionResult with success status and details
        """
        now = datetime.utcnow()

        # ── Gate 1: Risk approval ──────────────────────────────
        if not risk_result.approved:
            return ExecutionResult(
                success=False, signal=signal, order_result=None,
                rejection_reason=f"Risk check failed: {risk_result.reason}",
                is_paper=self._config.is_paper_mode,
                executed_at=now,
            )

        # ── Gate 2: Account balance minimum ───────────────────
        try:
            account = self._broker.get_account()
        except Exception as e:
            return ExecutionResult(
                success=False, signal=signal, order_result=None,
                rejection_reason=f"Could not fetch account info: {e}",
                is_paper=self._config.is_paper_mode,
                executed_at=now,
            )

        if account.balance < self._config.min_account_balance:
            return ExecutionResult(
                success=False, signal=signal, order_result=None,
                rejection_reason=(
                    f"Account balance {account.balance:.2f} is below "
                    f"minimum {self._config.min_account_balance:.2f}"
                ),
                is_paper=self._config.is_paper_mode,
                executed_at=now,
            )

        # ── Gate 3: Live spread check ──────────────────────────
        try:
            live_price = self._broker.get_price(signal.instrument)
        except Exception as e:
            return ExecutionResult(
                success=False, signal=signal, order_result=None,
                rejection_reason=f"Could not fetch live price: {e}",
                is_paper=self._config.is_paper_mode,
                executed_at=now,
            )

        # Determine pip size for spread calculation
        if "JPY" in signal.instrument:
            pip_size = 0.01
        elif "XAU" in signal.instrument or "XAG" in signal.instrument:
            pip_size = 0.01
        else:
            pip_size = 0.0001

        live_spread_pips = live_price.spread / pip_size

        if live_spread_pips > self._config.max_spread_pips:
            log.warning(
                "execution_rejected_spread",
                instrument=signal.instrument,
                spread_pips=round(live_spread_pips, 1),
                max_pips=self._config.max_spread_pips,
            )
            return ExecutionResult(
                success=False, signal=signal, order_result=None,
                rejection_reason=(
                    f"Live spread {live_spread_pips:.1f} pips exceeds "
                    f"maximum {self._config.max_spread_pips:.1f} pips"
                ),
                is_paper=self._config.is_paper_mode,
                executed_at=now,
                live_spread_pips=live_spread_pips,
                live_bid=live_price.bid,
                live_ask=live_price.ask,
            )

        # ── Gate 4: Recalculate position size vs live balance ──
        units, risk_amount = self._risk_engine.calculate_position_size(
            instrument=signal.instrument,
            entry_price=live_price.ask if signal.direction == "BUY" else live_price.bid,
            stop_loss=signal.stop_loss,
            account_equity=account.nav,
        )

        if units <= 0:
            return ExecutionResult(
                success=False, signal=signal, order_result=None,
                rejection_reason="Position size calculated as zero — check stop distance",
                is_paper=self._config.is_paper_mode,
                executed_at=now,
            )

        # ── Gate 5: Paper mode — simulate without submitting ──
        if self._config.is_paper_mode:
            log.info(
                "execution_paper_simulated",
                instrument=signal.instrument,
                direction=signal.direction,
                units=units,
                entry=live_price.ask if signal.direction == "BUY" else live_price.bid,
                sl=signal.stop_loss,
                tp=signal.take_profit,
                spread_pips=round(live_spread_pips, 1),
            )

            paper_result = OrderResult(
                success=True,
                order_id=f"PAPER_{now.strftime('%Y%m%d%H%M%S')}",
                trade_id=f"PAPER_{signal.instrument}_{now.strftime('%H%M%S')}",
                instrument=signal.instrument,
                direction=signal.direction,
                units=units,
                entry_price=live_price.ask if signal.direction == "BUY" else live_price.bid,
                stop_loss=signal.stop_loss,
                take_profit=signal.take_profit,
            )

            log_trade_open(
                log,
                instrument=signal.instrument,
                direction=signal.direction,
                entry_price=paper_result.entry_price,
                stop_loss=signal.stop_loss,
                take_profit=signal.take_profit,
                lot_size=units,
                strategy_id=signal.strategy_id,
                order_id=paper_result.order_id,
                is_paper=True,
            )

            return ExecutionResult(
                success=True, signal=signal, order_result=paper_result,
                rejection_reason=None, is_paper=True,
                executed_at=now, live_spread_pips=live_spread_pips,
                live_bid=live_price.bid, live_ask=live_price.ask,
            )

        # ── Gate 6: Live order submission ──────────────────────
        # Only reaches here if is_paper_mode=False AND all gates passed
        entry_price = live_price.ask if signal.direction == "BUY" else live_price.bid

        log.warning(
            "execution_live_order_submitting",
            instrument=signal.instrument,
            direction=signal.direction,
            units=units,
            entry=entry_price,
        )

        order_result = self._submit_with_retry(
            instrument=signal.instrument,
            direction=signal.direction,
            units=units,
            stop_loss=signal.stop_loss,
            take_profit=signal.take_profit,
        )

        if order_result.success:
            # Check slippage
            slippage_pips = abs(order_result.entry_price - entry_price) / pip_size
            if slippage_pips > self._config.max_slippage_pips:
                log.warning(
                    "execution_high_slippage",
                    slippage_pips=round(slippage_pips, 1),
                    expected=entry_price,
                    actual=order_result.entry_price,
                )

            log_trade_open(
                log,
                instrument=signal.instrument,
                direction=signal.direction,
                entry_price=order_result.entry_price,
                stop_loss=signal.stop_loss,
                take_profit=signal.take_profit,
                lot_size=units,
                strategy_id=signal.strategy_id,
                order_id=order_result.order_id,
                is_paper=False,
            )

            self._risk_engine.update_equity(account.nav)

        return ExecutionResult(
            success=order_result.success,
            signal=signal,
            order_result=order_result,
            rejection_reason=order_result.error_message if not order_result.success else None,
            is_paper=False,
            executed_at=now,
            live_spread_pips=live_spread_pips,
            live_bid=live_price.bid,
            live_ask=live_price.ask,
        )

    def _submit_with_retry(
        self,
        instrument: str,
        direction: str,
        units: float,
        stop_loss: float,
        take_profit: float,
    ) -> OrderResult:
        """Submit order with retry logic for transient failures."""
        import time

        last_error = None
        attempts = 1 + (self._config.max_retries if self._config.retry_on_failure else 0)

        for attempt in range(attempts):
            if attempt > 0:
                log.info(
                    "execution_retry",
                    attempt=attempt + 1,
                    max=attempts,
                )
                time.sleep(self._config.retry_delay_seconds)

            try:
                result = self._broker.submit_market_order(
                    instrument=instrument,
                    direction=direction,
                    units=units,
                    stop_loss=stop_loss,
                    take_profit=take_profit,
                )
                if result.success:
                    return result
                last_error = result.error_message
            except Exception as e:
                last_error = str(e)
                log.error(
                    "execution_submit_exception",
                    attempt=attempt + 1,
                    error=last_error,
                )

        from broker.base import OrderResult as OR
        return OR(
            success=False, order_id=None, trade_id=None,
            instrument=instrument, direction=direction,
            units=units, entry_price=0,
            stop_loss=stop_loss, take_profit=take_profit,
            error_message=f"All {attempts} attempts failed. Last: {last_error}",
        )

    def close_position(self, trade_id: str) -> bool:
        """Close an open position by trade ID."""
        log.info("execution_closing_trade", trade_id=trade_id)
        return self._broker.close_trade(trade_id)

    def get_open_positions(self):
        """Return all open positions from broker."""
        return self._broker.get_open_trades()
