"""
broker/oanda.py
────────────────
OANDA v20 REST API broker adapter for AtlasFX.

Implements BaseBroker against the OANDA v20 REST API.
Supports both practice and live accounts — controlled by
OANDA_ENVIRONMENT in .env.

OANDA API documentation:
    https://developer.oanda.com/rest-live-v20/introduction/

Practice endpoint : https://api-fxpractice.oanda.com
Live endpoint     : https://api-fxtrade.oanda.com

Rate limits:
    - 120 requests per second per access token
    - We stay well under this with a request delay

IMPORTANT: This module has been written against the published
OANDA v20 API specification. It has NOT been tested against
a live OANDA account. All order submission code should be
tested on a PRACTICE account first.

Instrument naming: OANDA uses underscore format (EUR_USD).
This matches AtlasFX's internal format — no conversion needed.

Units vs Lots:
    OANDA uses units, not lots.
    1 standard lot EUR_USD = 100,000 units
    The risk engine returns units directly.
    For XAU_USD, 1 unit = 1 troy ounce.
"""

from __future__ import annotations

import time
from datetime import datetime
from typing import Optional

import requests

from broker.base import (
    AccountInfo,
    BaseBroker,
    OpenTrade,
    OrderResult,
    Price,
)
from logs.logger import get_logger

log = get_logger(__name__)

# OANDA granularity map: AtlasFX timeframe → OANDA granularity
GRANULARITY_MAP = {
    "M1":  "M1",
    "M5":  "M5",
    "M15": "M15",
    "M30": "M30",
    "H1":  "H1",
    "H4":  "H4",
    "D":   "D",
    "W":   "W",
}


class OANDABroker(BaseBroker):
    """
    OANDA v20 REST API adapter.

    Connects to OANDA practice or live API using bearer token auth.
    All requests are synchronous (no async) for simplicity.

    Usage:
        broker = OANDABroker(
            api_key="your-oanda-api-key",
            account_id="your-account-id",
            environment="practice",  # or "live"
        )
        account = broker.get_account()
        price = broker.get_price("EUR_USD")
    """

    def __init__(
        self,
        api_key: str,
        account_id: str,
        environment: str = "practice",
        request_timeout: int = 10,
        min_request_interval: float = 0.1,  # seconds between requests
    ) -> None:
        if not api_key:
            raise ValueError("OANDA API key is required")
        if not account_id:
            raise ValueError("OANDA account ID is required")
        if environment not in ("practice", "live"):
            raise ValueError(f"environment must be 'practice' or 'live', got '{environment}'")

        self._api_key = api_key
        self._account_id = account_id
        self._environment = environment
        self._timeout = request_timeout
        self._min_interval = min_request_interval
        self._last_request_time = 0.0
        self._connected = False

        if environment == "live":
            self._base_url = "https://api-fxtrade.oanda.com"
        else:
            self._base_url = "https://api-fxpractice.oanda.com"

        self._session = requests.Session()
        self._session.headers.update({
            "Authorization": f"Bearer {self._api_key}",
            "Content-Type": "application/json",
            "Accept-Datetime-Format": "RFC3339",
        })

        log.info(
            "oanda_broker_initialised",
            environment=environment,
            account_id=account_id,
            base_url=self._base_url,
        )

    def _request(
        self,
        method: str,
        endpoint: str,
        params: Optional[dict] = None,
        json: Optional[dict] = None,
    ) -> dict:
        """
        Make a rate-limited request to the OANDA API.

        Raises:
            requests.HTTPError: On 4xx/5xx responses
            requests.ConnectionError: On network failure
        """
        # Rate limiting
        elapsed = time.time() - self._last_request_time
        if elapsed < self._min_interval:
            time.sleep(self._min_interval - elapsed)

        url = f"{self._base_url}{endpoint}"

        log.debug("oanda_request", method=method, endpoint=endpoint)

        try:
            response = self._session.request(
                method=method,
                url=url,
                params=params,
                json=json,
                timeout=self._timeout,
            )
            self._last_request_time = time.time()
            response.raise_for_status()
            return response.json()
        except requests.HTTPError as e:
            log.error(
                "oanda_http_error",
                status=e.response.status_code,
                endpoint=endpoint,
                body=e.response.text[:500],
            )
            raise
        except requests.ConnectionError as e:
            log.error("oanda_connection_error", endpoint=endpoint, error=str(e))
            raise

    # ── Connection test ───────────────────────────────────────

    def test_connection(self) -> bool:
        """
        Test API connectivity by fetching account summary.

        Returns:
            True if connected successfully, False otherwise.
        """
        try:
            self.get_account()
            self._connected = True
            log.info("oanda_connection_verified", account_id=self._account_id)
            return True
        except Exception as e:
            self._connected = False
            log.error("oanda_connection_failed", error=str(e))
            return False

    # ── BaseBroker implementation ─────────────────────────────

    @property
    def is_connected(self) -> bool:
        return self._connected

    @property
    def name(self) -> str:
        return f"OANDA ({self._environment})"

    def get_account(self) -> AccountInfo:
        """Fetch account summary from OANDA."""
        data = self._request(
            "GET",
            f"/v3/accounts/{self._account_id}/summary",
        )
        acct = data["account"]
        self._connected = True
        return AccountInfo(
            account_id=acct["id"],
            balance=float(acct["balance"]),
            nav=float(acct["NAV"]),
            unrealised_pnl=float(acct["unrealizedPL"]),
            margin_used=float(acct["marginUsed"]),
            margin_available=float(acct["marginAvailable"]),
            currency=acct["currency"],
            open_trade_count=int(acct["openTradeCount"]),
        )

    def get_price(self, instrument: str) -> Price:
        """Fetch current bid/ask for an instrument."""
        data = self._request(
            "GET",
            f"/v3/accounts/{self._account_id}/pricing",
            params={"instruments": instrument},
        )
        price_data = data["prices"][0]
        return Price(
            instrument=instrument,
            bid=float(price_data["bids"][0]["price"]),
            ask=float(price_data["asks"][0]["price"]),
            timestamp=datetime.fromisoformat(
                price_data["time"].replace("Z", "+00:00")
            ),
        )

    def get_open_trades(self) -> list[OpenTrade]:
        """Fetch all open trades."""
        data = self._request(
            "GET",
            f"/v3/accounts/{self._account_id}/openTrades",
        )
        trades = []
        for t in data.get("trades", []):
            units = float(t["currentUnits"])
            direction = "BUY" if units > 0 else "SELL"
            sl = float(t["stopLossOrder"]["price"]) if "stopLossOrder" in t else None
            tp = float(t["takeProfitOrder"]["price"]) if "takeProfitOrder" in t else None
            trades.append(OpenTrade(
                trade_id=t["id"],
                instrument=t["instrument"],
                direction=direction,
                units=abs(units),
                entry_price=float(t["price"]),
                current_price=float(t.get("currentUnits", t["price"])),
                stop_loss=sl,
                take_profit=tp,
                unrealised_pnl=float(t["unrealizedPL"]),
                open_time=datetime.fromisoformat(
                    t["openTime"].replace("Z", "+00:00")
                ),
            ))
        return trades

    def submit_market_order(
        self,
        instrument: str,
        direction: str,
        units: float,
        stop_loss: float,
        take_profit: float,
    ) -> OrderResult:
        """
        Submit a market order with attached SL and TP to OANDA.

        OANDA uses signed units:
            Positive units = BUY
            Negative units = SELL

        Stop loss and take profit are submitted as linked orders.

        NOTE: This has been written to the OANDA v20 spec but has
        NOT been tested against a live or practice account.
        Always test on practice first.
        """
        if direction not in ("BUY", "SELL"):
            return OrderResult(
                success=False, order_id=None, trade_id=None,
                instrument=instrument, direction=direction,
                units=units, entry_price=0, stop_loss=stop_loss,
                take_profit=take_profit,
                error_message=f"Invalid direction: {direction}",
            )

        signed_units = units if direction == "BUY" else -units

        # Determine pip precision for the instrument
        if "JPY" in instrument:
            price_precision = 3
        elif "XAU" in instrument or "XAG" in instrument:
            price_precision = 2
        else:
            price_precision = 5

        order_body = {
            "order": {
                "type": "MARKET",
                "instrument": instrument,
                "units": str(int(signed_units)),
                "timeInForce": "FOK",          # Fill or Kill
                "positionFill": "DEFAULT",
                "stopLossOnFill": {
                    "price": str(round(stop_loss, price_precision)),
                    "timeInForce": "GTC",
                },
                "takeProfitOnFill": {
                    "price": str(round(take_profit, price_precision)),
                    "timeInForce": "GTC",
                },
            }
        }

        log.info(
            "oanda_order_submitting",
            instrument=instrument,
            direction=direction,
            units=int(signed_units),
            sl=round(stop_loss, price_precision),
            tp=round(take_profit, price_precision),
        )

        try:
            data = self._request(
                "POST",
                f"/v3/accounts/{self._account_id}/orders",
                json=order_body,
            )

            # Parse OANDA response
            fill = data.get("orderFillTransaction", {})
            order_create = data.get("orderCreateTransaction", {})

            if fill:
                trade_id = fill.get("tradeOpened", {}).get("tradeID")
                entry_price = float(fill.get("price", 0))
                order_id = fill.get("orderID") or order_create.get("orderID")

                log.info(
                    "oanda_order_filled",
                    instrument=instrument,
                    direction=direction,
                    trade_id=trade_id,
                    entry_price=entry_price,
                )

                return OrderResult(
                    success=True,
                    order_id=order_id,
                    trade_id=trade_id,
                    instrument=instrument,
                    direction=direction,
                    units=units,
                    entry_price=entry_price,
                    stop_loss=stop_loss,
                    take_profit=take_profit,
                )
            else:
                # Order cancelled or rejected
                cancel = data.get("orderCancelTransaction", {})
                reason = cancel.get("reason", "Unknown rejection reason")
                log.warning(
                    "oanda_order_rejected",
                    instrument=instrument,
                    reason=reason,
                )
                return OrderResult(
                    success=False, order_id=None, trade_id=None,
                    instrument=instrument, direction=direction,
                    units=units, entry_price=0,
                    stop_loss=stop_loss, take_profit=take_profit,
                    error_message=reason,
                )

        except Exception as e:
            log.error(
                "oanda_order_failed",
                instrument=instrument,
                error=str(e),
            )
            return OrderResult(
                success=False, order_id=None, trade_id=None,
                instrument=instrument, direction=direction,
                units=units, entry_price=0,
                stop_loss=stop_loss, take_profit=take_profit,
                error_message=str(e),
            )

    def close_trade(self, trade_id: str) -> bool:
        """Close an open trade at market price."""
        try:
            self._request(
                "PUT",
                f"/v3/accounts/{self._account_id}/trades/{trade_id}/close",
            )
            log.info("oanda_trade_closed", trade_id=trade_id)
            return True
        except Exception as e:
            log.error("oanda_close_failed", trade_id=trade_id, error=str(e))
            return False

    def modify_trade(
        self,
        trade_id: str,
        stop_loss: Optional[float] = None,
        take_profit: Optional[float] = None,
    ) -> bool:
        """Modify SL or TP on an open trade."""
        body: dict = {"tradeID": trade_id}
        orders = {}

        if stop_loss is not None:
            orders["stopLoss"] = {
                "price": str(round(stop_loss, 5)),
                "timeInForce": "GTC",
            }
        if take_profit is not None:
            orders["takeProfit"] = {
                "price": str(round(take_profit, 5)),
                "timeInForce": "GTC",
            }

        if not orders:
            return True  # Nothing to modify

        try:
            self._request(
                "PUT",
                f"/v3/accounts/{self._account_id}/trades/{trade_id}/orders",
                json=orders,
            )
            log.info(
                "oanda_trade_modified",
                trade_id=trade_id,
                sl=stop_loss,
                tp=take_profit,
            )
            return True
        except Exception as e:
            log.error("oanda_modify_failed", trade_id=trade_id, error=str(e))
            return False

    def get_candles(
        self,
        instrument: str,
        granularity: str,
        count: int = 500,
    ) -> list[dict]:
        """
        Fetch OHLCV candles from OANDA.

        OANDA returns candles in this format:
            {
                "time": "2024-01-01T00:00:00Z",
                "mid": {"o": "1.1050", "h": "1.1080", "l": "1.1030", "c": "1.1065"},
                "volume": 1234,
                "complete": true
            }

        We normalise to AtlasFX format: {time, open, high, low, close, volume}
        """
        oanda_granularity = GRANULARITY_MAP.get(granularity, granularity)

        data = self._request(
            "GET",
            f"/v3/instruments/{instrument}/candles",
            params={
                "granularity": oanda_granularity,
                "count": min(count, 5000),
                "price": "M",  # Midpoint candles
            },
        )

        candles = []
        for c in data.get("candles", []):
            if not c.get("complete", True):
                continue  # Skip incomplete (current) candle
            mid = c["mid"]
            candles.append({
                "time": c["time"],
                "open":   float(mid["o"]),
                "high":   float(mid["h"]),
                "low":    float(mid["l"]),
                "close":  float(mid["c"]),
                "volume": int(c.get("volume", 0)),
            })

        log.debug(
            "oanda_candles_fetched",
            instrument=instrument,
            granularity=oanda_granularity,
            count=len(candles),
        )
        return candles

    def get_candles_as_dataframe(
        self,
        instrument: str,
        granularity: str,
        count: int = 500,
    ):
        """
        Fetch candles and return as a pandas DataFrame.

        Returns DataFrame with columns: Open, High, Low, Close, Volume
        Indexed by UTC datetime.
        """
        import pandas as pd

        candles = self.get_candles(instrument, granularity, count)
        if not candles:
            return pd.DataFrame()

        df = pd.DataFrame(candles)
        df["time"] = pd.to_datetime(df["time"], utc=True).dt.tz_localize(None)
        df = df.set_index("time")
        df.columns = [c.capitalize() for c in df.columns]
        df = df.rename(columns={"Open": "Open", "High": "High",
                                  "Low": "Low", "Close": "Close",
                                  "Volume": "Volume"})
        return df
