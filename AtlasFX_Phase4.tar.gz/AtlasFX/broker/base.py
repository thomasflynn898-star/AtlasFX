"""
broker/base.py
───────────────
Abstract broker interface for AtlasFX.

All broker implementations must inherit from BaseBroker and implement
every abstract method. This ensures the execution engine can swap
brokers without changing any other code.

Supported brokers (planned):
    - OANDA v20 REST API (Phase 4 — this file)
    - Interactive Brokers TWS (Phase 7)

The broker layer is responsible for:
    - Account information
    - Historical candle data
    - Current prices (spread, bid, ask)
    - Submitting market orders with SL/TP
    - Querying open positions
    - Closing positions
    - Modifying SL/TP on open positions

The broker layer is NOT responsible for:
    - Risk calculations (risk engine)
    - Signal generation (strategies)
    - Position sizing (risk engine)
    - Trade logging (journal)
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import datetime
from typing import Optional


@dataclass
class AccountInfo:
    """Broker account snapshot."""
    account_id: str
    balance: float
    nav: float               # Net Asset Value
    unrealised_pnl: float
    margin_used: float
    margin_available: float
    currency: str
    open_trade_count: int


@dataclass
class Price:
    """Current bid/ask price for an instrument."""
    instrument: str
    bid: float
    ask: float
    timestamp: datetime

    @property
    def mid(self) -> float:
        return round((self.bid + self.ask) / 2, 5)

    @property
    def spread(self) -> float:
        return round(self.ask - self.bid, 5)


@dataclass
class OrderResult:
    """Result of a submitted order."""
    success: bool
    order_id: Optional[str]
    trade_id: Optional[str]
    instrument: str
    direction: str
    units: float
    entry_price: float
    stop_loss: float
    take_profit: float
    error_message: Optional[str] = None


@dataclass
class OpenTrade:
    """A currently open trade at the broker."""
    trade_id: str
    instrument: str
    direction: str           # BUY or SELL
    units: float
    entry_price: float
    current_price: float
    stop_loss: Optional[float]
    take_profit: Optional[float]
    unrealised_pnl: float
    open_time: datetime


class BaseBroker(ABC):
    """
    Abstract base class for all broker implementations.

    Every method that touches the broker API must be implemented.
    No default implementations are provided — each broker has
    different API semantics and should be explicit.
    """

    @abstractmethod
    def get_account(self) -> AccountInfo:
        """Return current account balance and margin info."""
        ...

    @abstractmethod
    def get_price(self, instrument: str) -> Price:
        """Return current bid/ask for an instrument."""
        ...

    @abstractmethod
    def get_open_trades(self) -> list[OpenTrade]:
        """Return all currently open trades."""
        ...

    @abstractmethod
    def submit_market_order(
        self,
        instrument: str,
        direction: str,
        units: float,
        stop_loss: float,
        take_profit: float,
    ) -> OrderResult:
        """
        Submit a market order with attached SL and TP.

        Args:
            instrument: e.g. 'EUR_USD'
            direction: 'BUY' or 'SELL'
            units: Number of units (positive integer)
            stop_loss: Stop loss price
            take_profit: Take profit price

        Returns:
            OrderResult with success status and order/trade IDs
        """
        ...

    @abstractmethod
    def close_trade(self, trade_id: str) -> bool:
        """
        Close an open trade at market price.

        Returns:
            True if successfully closed, False otherwise
        """
        ...

    @abstractmethod
    def modify_trade(
        self,
        trade_id: str,
        stop_loss: Optional[float] = None,
        take_profit: Optional[float] = None,
    ) -> bool:
        """
        Modify the SL or TP of an open trade.

        Returns:
            True if successfully modified, False otherwise
        """
        ...

    @abstractmethod
    def get_candles(
        self,
        instrument: str,
        granularity: str,
        count: int,
    ) -> list[dict]:
        """
        Fetch recent OHLCV candles.

        Args:
            instrument: e.g. 'EUR_USD'
            granularity: OANDA granularity e.g. 'H1', 'D', 'H4'
            count: Number of candles to fetch (max 5000)

        Returns:
            List of dicts with keys: time, open, high, low, close, volume
        """
        ...

    @property
    @abstractmethod
    def is_connected(self) -> bool:
        """Return True if broker connection is live."""
        ...

    @property
    @abstractmethod
    def name(self) -> str:
        """Human-readable broker name."""
        ...
